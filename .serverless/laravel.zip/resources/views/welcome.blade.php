<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
    </head>
    <body class="antialiased">
            <div class="max-w-6xl mx-auto sm:px-6 lg:px-8">
                <div class="text-center">
                    <h1 class=" center text-3xl font-extrabold leading-9 tracking-tight text-gray-900 sm:text-4xl sm:leading-10">
                        {{ __('Welcome to Laravel Serveless') }}
                    </h1>
                </div>
            </div>
        </div>
    </body>
</html>
